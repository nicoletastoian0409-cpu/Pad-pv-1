plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "ro.pad.procesverbal"; compileSdk = 35
    defaultConfig { applicationId = "ro.pad.procesverbal"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
