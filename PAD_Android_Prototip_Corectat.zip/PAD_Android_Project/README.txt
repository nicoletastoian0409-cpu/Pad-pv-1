PAD – Proces-verbal | prototip Android (cod-sursă)

Acest ZIP NU este un APK. Nu a fost compilat sau testat pe telefon.

Pentru compilare fără instalarea de programe pe PC: se poate încărca întregul proiect într-un repository GitHub privat și rula workflow-ul .github/workflows/android-apk.yml. Rezultatul ar trebui să fie un APK debug în secțiunea Artifacts a rulării, dar construcția nu a fost verificată aici. NU încărca documente cadastrale reale în repository.

Funcții existente în prototip: alegere multiplă de PDF-uri, citire text din PDF-uri digitale, editare manuală, generare Word.
Lipsesc: OCR pentru PDF-uri scanate, recunoaștere cadastrală robustă, reproducere fidelă a modelului oficial, testare pe Android.
Necesită internet pentru bibliotecile JavaScript externe. Nu introduce documente sensibile înainte de auditarea și testarea aplicației.
