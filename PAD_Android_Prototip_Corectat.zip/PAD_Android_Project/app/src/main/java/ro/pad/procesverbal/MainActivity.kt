package ro.pad.procesverbal

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.app.DownloadManager
import android.os.Environment
import android.content.Context
import android.util.Base64
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequestCode = 55
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }, fileRequestCode)
                    true
                } catch (e: Exception) { fileCallback = null; false }
            }
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                android.app.AlertDialog.Builder(this@MainActivity).setMessage(message).setPositiveButton("Da") { _, _ -> result?.confirm() }.setNegativeButton("Nu") { _, _ -> result?.cancel() }.show()
                return true
            }
        }
        web.webViewClient = WebViewClient()
        web.setDownloadListener { url, _, _, mime, _ ->
            try {
                if (url.startsWith("blob:")) {
                    web.evaluateJavascript("(async()=>{let b=await (await fetch('"+url+"')).arrayBuffer();let a=new Uint8Array(b);let s='';for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode(...a.subarray(i,i+8192));Android.saveDoc(btoa(s));})()", null)
                } else {
                    val req=DownloadManager.Request(Uri.parse(url)).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"Proces_verbal.docx").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                }
            } catch(e:Exception){ Toast.makeText(this,"Nu s-a putut salva documentul",Toast.LENGTH_LONG).show() }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveDoc(base64: String) {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val values = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "Proces_verbal_${System.currentTimeMillis()}.docx")
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                        put(android.provider.MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
                    if(uri!=null){ contentResolver.openOutputStream(uri)?.use{it.write(bytes)};runOnUiThread { Toast.makeText(this@MainActivity,"Word salvat în Descărcări",Toast.LENGTH_LONG).show() } }
                } catch(e:Exception){ runOnUiThread { Toast.makeText(this@MainActivity,"Eroare la salvare",Toast.LENGTH_LONG).show() } }
            }
        },"Android")
        web.loadUrl("file:///android_asset/index.html")
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==fileRequestCode){
            val result = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                else data.data?.let { arrayOf(it) }
            } else null
            fileCallback?.onReceiveValue(result)
            fileCallback=null
        }
    }
    override fun onBackPressed() { if(web.canGoBack()) web.goBack() else super.onBackPressed() }
}
